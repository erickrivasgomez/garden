# Boostrap basic page


## Getting started 🚀

git clone https://github.com/rivaserick/bootstrap-homework


```
git clone https://github.com/rivaserick/bootstrap-homework
```

Installation

```
npm i
```

### Used components:

* Card
* Modal
* Input-group
* Nav Bar
* Badge
* Carousel
* List
* Footer
* Alert

### Icons:

[Boxicons - https://boxicons.com/](https://boxicons.com/)
